# -*- coding: utf-8 -*-
"""
Created on Mon Aug 29 11:19:27 2022

@author: lukas
"""

#%% Import
import pypsa
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import plotly.io as pio

from makeplots1 import makeplots

#%% Set up network

n_timesteps = 4

network = pypsa.Network()

#Add bus
network.add("Bus",    #Component Type
            "My Bus", #Component name
            )

network.set_snapshots(range(n_timesteps)) #Set up snapshots of unitless time

#%% Add generators
    #Add dynamic generator "Wind1"
network.add("Generator",
            "Wind (0.1)",
            bus = "My Bus", 
            p_nom = 30,
            p_max_pu = [0.1, 1, 0.4, 0.2],
            marginal_cost = 0.1,
            )

network.add("Generator",
            "Coal (1)",
            bus = "My Bus", 
            p_nom = 12,
            marginal_cost = 1
            )

network.add("Generator",
            "Coal2 (0.3)",
            bus = "My Bus", 
            p_nom = 8,
            marginal_cost = 0.3
            )

#%% Add loads
    #Add dynamic load
network.add("Load",
            "Load1",
            bus = "My Bus",
            p_set = [15,20,4,20] #Load at each time interval
            )

#%% Add stores
    #Add storage
network.add("Store",
            "Store1",
            bus = "My Bus",
            e_nom = 5,    #Store capacity
            e_initial = 0    #Initial stored energy
            )

#%% Solve system

network.lopf() #Solve dynamic system
        
makeplots(network)


